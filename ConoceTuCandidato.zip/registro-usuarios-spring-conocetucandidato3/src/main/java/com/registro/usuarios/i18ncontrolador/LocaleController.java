package com.registro.usuarios.i18ncontrolador;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.support.RequestContextUtils;
import org.springframework.util.StringUtils;


@Controller
public class LocaleController {

	@RequestMapping("/locale")
	public String locale() {
        return "index";
    }


    @PostMapping("/locale")
    public String changeLocale(@RequestParam(name = "lang") String lang, HttpServletRequest request) {
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
        if (localeResolver != null) {
            localeResolver.setLocale(request, null, StringUtils.parseLocaleString(lang));
        }
        return "redirect:/";
    }
}
