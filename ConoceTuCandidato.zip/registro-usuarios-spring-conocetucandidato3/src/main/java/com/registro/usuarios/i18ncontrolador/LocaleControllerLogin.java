package com.registro.usuarios.i18ncontrolador;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.support.RequestContextUtils;
import org.springframework.util.StringUtils;


@Controller
@RequestMapping("/login")
public class LocaleControllerLogin {

    @GetMapping("/cambiarIdioma")
    public String loginPage(Model model) {
        return "login";
    }

    @GetMapping("/locale")
    public String changeLocaleGet(@RequestParam(name = "lang") String lang, HttpServletRequest request, HttpServletResponse response) {
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
        if (localeResolver != null) {
            localeResolver.setLocale(request, response, StringUtils.parseLocaleString(lang));
        }
        return "redirect:/login";
    }

    @PostMapping("/locale")
    public String changeLocalePost(@RequestParam(name = "lang") String lang, HttpServletRequest request, HttpServletResponse response) {
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
        if (localeResolver != null) {
            localeResolver.setLocale(request, response, StringUtils.parseLocaleString(lang));
        }
        return "redirect:/login";
    }
}


