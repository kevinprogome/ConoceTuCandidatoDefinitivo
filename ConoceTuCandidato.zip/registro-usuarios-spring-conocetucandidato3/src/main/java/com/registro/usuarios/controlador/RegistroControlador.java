package com.registro.usuarios.controlador;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import com.registro.usuarios.servicio.UsuarioServicio;

@Controller
public class RegistroControlador {

	@Autowired
	private UsuarioServicio servicio;

    @GetMapping("/login")
    public String iniciarSesion(@RequestParam(name = "lang", required = false) String lang, HttpServletRequest request) {
        if (lang != null) {
            request.getSession().setAttribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME, new Locale(lang));
        }

        Locale currentLocale = (Locale) request.getSession().getAttribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME);
        System.out.println("Lang parameter: " + lang);
        System.out.println("Current Locale: " + currentLocale);

        return "login";
    }


	@GetMapping("/")
	public String verPaginaDeInicio(Model modelo) {
		int sumaVotosAmin = servicio.calcularSumaVotos("Amin");
		modelo.addAttribute("sumaVotosAmin", sumaVotosAmin);
		
		int sumaVotosDagoberto = servicio.calcularSumaVotos("Dagoberto");
		modelo.addAttribute("sumaVotosDagoberto", sumaVotosDagoberto);
		
		int sumaVotosCasagua = servicio.calcularSumaVotos("Casagua");
		modelo.addAttribute("sumaVotosCasagua", sumaVotosCasagua);
		
		int sumaVotosChicho = servicio.calcularSumaVotos("Chicho");
		modelo.addAttribute("sumaVotosChicho", sumaVotosChicho);
		
		int sumaVotosBotello = servicio.calcularSumaVotos("Botello");
		modelo.addAttribute("sumaVotosBotello", sumaVotosBotello);
		
		int sumaVotosJorge = servicio.calcularSumaVotos("Jorge");
		modelo.addAttribute("sumaVotosJorge", sumaVotosJorge);
		
		int sumaVotosWilker = servicio.calcularSumaVotos("Wilker");
		modelo.addAttribute("sumaVotosWilker", sumaVotosWilker);
		
		int sumaVotosWilmar = servicio.calcularSumaVotos("Wilmar");
		modelo.addAttribute("sumaVotosWilmar", sumaVotosWilmar);
		
		int sumaVotosYilber = servicio.calcularSumaVotos("Yilber");
		modelo.addAttribute("sumaVotosYilber", sumaVotosYilber);
		
		



		return "index";
	}
	
	   @GetMapping("/inicio")
	    public String mostrarPaginaInicio() {
	        return "inicio";
	    }
	   
		@GetMapping("/dagobertomarin")
		public String mostrarCandidato1() {
			return "DagobertoMarin";
		}

		@GetMapping("/edinsonamin")
		public String mostrarCandidato2() {
			return "EdinsonAmin";
		}

		@GetMapping("/germancasagua")
		public String mostrarCandidato3() {
			return "GermanCasagua";
		}
		
		@GetMapping("/germandario")
		public String mostrarCandidato9() {
			return "GermanDario";
		}

		@GetMapping("/hectorbotello")
		public String mostrarCandidato4() {
			return "HectorBotello";
		}
		
		@GetMapping("/jorgeandres")
		public String mostrarCandidato5() {
			return "JorgeAndresGechem";
		}
		
		@GetMapping("/wilkerbautista")
		public String mostrarCandidato6() {
			return "WilkerBautista";
		}
		
		@GetMapping("/wilmarcharry")
		public String mostrarCandidato7() {
			return "WilmarCharry";
		}
		
		@GetMapping("/yilbersaavedra")
		public String mostrarCandidato8() {
			return "YilberSaavedra";
		}
		
    @GetMapping("/candidatos")
    public String mostrarPaginaCandidatos() {
        return "CandidatosDef";
    }

	
	@RequestMapping("/cambiarLocale")
	public String changeLocale(@RequestParam("lang") String lang, HttpServletRequest request) {
	    Locale locale = new Locale(lang);
	    request.getSession().setAttribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME, locale);
	    return "redirect:/";
	}


}
